﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot
{
    public interface IVehicle
    {
        string getColor();
        string getRegistrationNumber();
    }

    class Car : IVehicle
    {
        public string color;
        public string registrationno;

        public Car(string colour,string regno)
        {
            color = colour;
            registrationno = regno;
        }
        public string getColor()
        {
            return color;
        }
        public string getRegistrationNumber()
        {
            return registrationno;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
