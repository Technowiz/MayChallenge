﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot
{
	public class ParkingLot
	{
		public static ParkingLot parkingLot;
		public Dictionary<int, Slot> slots;

		/**
		 * VisibleForTesting(otherwise = PRIVATE)
		 */
		public ParkingLot(int numberOfSlots)
		{
			slots = new Dictionary<int, Slot>();
			for (int i = 1; i <= numberOfSlots; i++)
			{
				slots.Add(i, new Slot(i));
			}
		}

		/**
		 * Singleton Class => Returns a single instance of the class
		 * 
		 * @param numberOfSlots => number of slots in the parking lot
		 * @return ParkingLot instance
		 */
		public static ParkingLot getInstance(int numberOfSlots)
		{
			if (parkingLot == null)
			{
				parkingLot = new ParkingLot(numberOfSlots);
			}
			return parkingLot;
		}

		/**
		 * Finds the next available slot and marks it unavailable
		 * 
		 * @return slot number which was marked unavailable
		 */
		public int fillAvailableSlot()
		{
			int nextAvailableSlotNumber = -1;
			for (int i = 1; i <= slots.Count(); i++)
			{
				Slot s = slots[i];
				if (s.status)
				{
					nextAvailableSlotNumber = s.slotNumber;
					s.status = false;
					break;
				}
			}
			if (nextAvailableSlotNumber != -1)
			{
				return nextAvailableSlotNumber;
			}
			else
			{
				throw new Exception("Sorry, parking lot is full");
			}
		}

		/**
		 * Empties the Slot => marks the slot available
		 * 
		 * @param slotNumber => the slot number to be made empty
		 */
		public void emptySlot(int slotNumber)
		{
			if (slots.ContainsKey(slotNumber))
			{
				if (slots[slotNumber].status)
				{
					throw new Exception("The slot is already empty");
				}
				else
				{
					slots[slotNumber].status = true;
				}
			}
			else
			{
				throw new Exception("The slot number is invalid");
			}
		}

		/**
		 * private Class => Slot is an entity known only to parking lot.
		 *
		 */
		public class Slot
		{
			// unique slot identifier
			public int slotNumber;
			// boolean status to maintain isAvailable => true=available, false=not available
			public bool status;

			public Slot(int slotNumber)
			{
				this.slotNumber = slotNumber;
				this.status = true;
			}
		}
	}
}
