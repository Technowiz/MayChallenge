﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot
{
	public class StatusResponse
	{
		private int slotNumber;
		private String registrationNumber;
		private String color;

		public StatusResponse(int slotNumber, String registrationNumber, String color)
		{
			this.slotNumber = slotNumber;
			this.registrationNumber = registrationNumber;
			this.color = color;
		}

		public int getSlotNumber()
		{
			return slotNumber;
		}

		public String getRegistrationNumber()
		{
			return registrationNumber;
		}

		public String getColor()
		{
			return color;
		}

		
		public override string ToString()
		{
			return slotNumber + "           " + registrationNumber + "      " + color;
		}

	}
}
