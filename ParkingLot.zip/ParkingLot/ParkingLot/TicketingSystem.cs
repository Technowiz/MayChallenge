﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot
{
	public class TicketingSystem
	{
		public static TicketingSystem ticketingSystem;
		public ParkingLot parkingLot;
		public Dictionary<int, Ticket> tickets;

		
		public TicketingSystem(ParkingLot parkingLot)
		{
			this.parkingLot = parkingLot;
			tickets = new Dictionary<int, Ticket>();
		}

		/**
		 * Singleton Class => Returns a single instance of the class
		 * 
		 * @param numberOfSlots => Number of slots of the parking lot that this
		 *                      ticketing system is managing
		 * @return TicketingSystem instance
		 */
		public static TicketingSystem createInstance(int numberOfSlots)
		{
			if (numberOfSlots < 1)
			{
				throw new Exception("Number of slots cannot be less than 1");
			}
			if (ticketingSystem == null)
			{
				ParkingLot parkingLot = ParkingLot.getInstance(numberOfSlots);
				ticketingSystem = new TicketingSystem(parkingLot);
			}
			return ticketingSystem;
		}

		/**
		 * 
		 * @return TicketingSystem instance
		 */
		public static TicketingSystem getInstance()
		{
			if (ticketingSystem == null)
			{
				throw new Exception("Parking Lot is not initialized");
			}
			return ticketingSystem;
		}

		/**
		 * Parks a vehicle
		 * 
		 * @return slotNumber => slot number at which the vehicle needs to be parked
		 */
		public int issueParkingTicket(IVehicle vehicle)
		{
			if (vehicle == null)
			{
				throw new Exception("Vehicle cannot be null");
			}
			int assignedSlotNumber = parkingLot.fillAvailableSlot();
			Ticket ticket = new Ticket(assignedSlotNumber, vehicle);
			tickets.Add(assignedSlotNumber, ticket);
			return assignedSlotNumber;
		}

		/**
		 * Exits a vehicle from the parking lot
		 * 
		 * @param registrationNumber
		 * @return slotNumber => the slot from the car has exited.
		 */
		public void exitVehicle(int slotNumber)
		{
			if (tickets.ContainsKey(slotNumber))
			{
				parkingLot.emptySlot(slotNumber);
				tickets.Remove(slotNumber);
				return;
			}
			else
			{
				throw new Exception("No vehicle found at given slot. Incorrect input");
			}
		}

		/**
		 * returns all the registration numbers of the vehicles with the given color
		 * 
		 * @param color => Color of the Vehicle
		 * @return List of all the registration numbers of the vehicles with the given
		 *         color
		 */
		public List<String> getRegistrationNumbersFromColor(String color)
		{
			if (color == null)
			{
				throw new Exception("color cannot be null");
			}
			List<String> registrationNumbers = new List<String>();
			foreach (Ticket ticket in tickets.Values)
			{
				if (color.Equals(ticket.vehicle.getColor()))
				{
					registrationNumbers.Add(ticket.vehicle.getRegistrationNumber());
				}
			}
			return registrationNumbers;
		}

		/**
		 * returns the slot number at which the Vehicle with given registrationNumber is
		 * parked
		 * 
		 * @param registrationNumber => Registration Number of the Vehicle
		 * @return slot number at which the Vehicle with given registrationNumber is
		 *         parked
		 */
		public int getSlotNumberFromRegistrationNumber(String registrationNumber)
		{
			if (registrationNumber == null)
			{
				throw new Exception("registrationNumber cannot be null");
			}
			foreach (Ticket ticket in tickets.Values)
			{
				if (registrationNumber.Equals(ticket.vehicle.getRegistrationNumber()))
				{
					return ticket.slotNumber;
				}
			}

			throw new Exception("Not found");
		}

		/**
		 * returns all the slot numbers of the vehicles with the given color
		 * 
		 * @param color => Color of the Vehicle
		 * @return List of all the slot numbers of the vehicles with the given color
		 */
		public List<int> getSlotNumbersFromColor(String color)
		{
			if (color == null)
			{
				throw new Exception("color cannot be null");
			}
			List<int> registrationNumbers = new List<int>();
			foreach (Ticket ticket in tickets.Values)
			{
				if (color.Equals(ticket.vehicle.getColor()))
				{
					registrationNumbers.Add(ticket.slotNumber);
				}
			}
			return registrationNumbers;
		}

		/**
		 * returns the status of the ticketing system, a list of all the tickets
		 * converted to status objects
		 * 
		 * @return List of StatusResponse => List of (slotNumber, registrationNumber,
		 *         color)
		 */
		public List<StatusResponse> getStatus()
		{
			List<StatusResponse> statusResponseList = new List<StatusResponse>();
			foreach (Ticket ticket in tickets.Values)
			{
				statusResponseList.Add(new StatusResponse(ticket.slotNumber, ticket.vehicle.getRegistrationNumber(),
						ticket.vehicle.getColor()));
			}
			return statusResponseList;
		}

		/**
		 * Ticketing System issues a ticket => an object known only to Ticketing System
		 *
		 */
		public class Ticket
		{
			public int slotNumber;
			public IVehicle vehicle;

			public Ticket(int slotNumber, IVehicle vehicle)
			{
				this.slotNumber = slotNumber;
				this.vehicle = vehicle;
			}
		}
	}
}
