﻿using ParkingLot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot
{
	public class CommandExecutor
	{
		private static CommandExecutor commandExecutor;

		private CommandExecutor()
		{

		}

		/**
		 * Singleton Class => Returns a single instance of the class
		 * 
		 * @return CommandExecutor instance
		 */
		public static CommandExecutor getInstance()
		{
			if (commandExecutor == null)
			{
				commandExecutor = new CommandExecutor();
			}
			return commandExecutor;
		}

		public CommandName getCommandName(string commandString)
		{

			CommandName commandName=CommandName.create_parking_lot;

			if (commandString == null)
			{
				Console.WriteLine("Not a valid input");
			}
			else
			{
				string[] commandStringArray = commandString.Split(' ');
				if ("".Equals(commandStringArray[0]))
				{
					Console.WriteLine("Not a valid input");
				}
				else
				{
					try
					{
						if (commandStringArray[0] == "create_parking_lot")
							commandName = CommandName.create_parking_lot;
						
					}
					catch (Exception ex)
					{
						Console.WriteLine(ex.Message);
					}
				}
			}
			return commandName;

		}

		/**
		 * the main function to execute the commands 
		 * @param commandString
		 * @return boolean if the execution is success or not
		 */
		public bool execute(string commandString)
		{

			CommandName commandName = getCommandName(commandString);

			if (commandName==null)
			{
				return false;
			}
			string[] commandStringArray = commandString.Split(' ');
			Command command;

			switch (commandName)
			{
				case CommandName.create_parking_lot:
					command = new CreateParkingLotCommand(commandStringArray);
					break;
				case CommandName.park:
					command = new ParkCommand(commandStringArray);
					break;
				case CommandName.leave:
					command = new LeaveCommand(commandStringArray);
					break;
				case CommandName.status:
					command = new StatusCommand(commandStringArray);
					break;
				case CommandName.registration_numbers_for_cars_with_colour:
					command = new RegistrationNumbersForColorCommand(commandStringArray);
					break;
				case CommandName.slot_numbers_for_cars_with_colour:
					command = new SlotNumbersForColorCommand(commandStringArray);
					break;
				case CommandName.slot_number_for_registration_number:
					command = new SlotNumberCommand(commandStringArray);
					break;
				default:
					Console.WriteLine("Unknown Command");
					return false;
			}

			try
			{
				command.validate();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return false;
			}

			String output = "";
			try
			{
				output = command.execute();
			}
		
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			
				return false;
			}
			Console.WriteLine(output);
			return true;
		}

		/**
		 * All CommandNames
		 *
		 */
		public enum CommandName
		{
			create_parking_lot, park, leave, status, registration_numbers_for_cars_with_colour,
			slot_numbers_for_cars_with_colour, slot_number_for_registration_number
		}

		/**
		 * Command Interface which validates & executes the command
		 *
		 */
		private interface Command
		{
			void validate();

			string execute();
		}

		/**
		 * Command Implementing create_parking_lot
		 *
		 */
		private class CreateParkingLotCommand : Command
		{
		private string[] commandStringArray;

		public CreateParkingLotCommand(string[] s)
		{
			commandStringArray = s;
		}

		public void validate()
		{
			if (commandStringArray.Length != 2)
			{
				throw new Exception("create_parking_lot command should have exactly 1 argument");
			}
		}

		public String execute()
		{
			int numberOfSlots = Int32.Parse(commandStringArray[1]);
			TicketingSystem.createInstance(numberOfSlots);
			return "Created a parking lot with " + commandStringArray[1] + " slots";
		}
	}

	/**
	 * holds the responsibility of implementing park command
	 *
	 */
	public class ParkCommand : Command
	{
		private string[] commandStringArray;

	public ParkCommand(string[] s)
	{
		commandStringArray = s;
	}

	public void validate()
	{
		if (commandStringArray.Length != 3)
		{
			throw new Exception("park command should have exactly 2 arguments");
		}
	}

	public String execute()
	{
		TicketingSystem ticketingSystem = TicketingSystem.getInstance();
		int allocatedSlotNumber = ticketingSystem
				.issueParkingTicket(new Car(commandStringArray[1], commandStringArray[2]));
		return "Allocated slot number: " + allocatedSlotNumber;
	}
}

/**
 * holds the responsibility of implementing leave command
 *
 */
public class LeaveCommand : Command
{
		private String[] commandStringArray;

		public LeaveCommand(String[] s)
		{
			commandStringArray = s;
		}

public void validate()
{
	if (commandStringArray.Length != 2)
	{
		throw new Exception("leave command should have exactly 1 argument");
	}
}

		public String execute()
		{
			TicketingSystem ticketingSystem = TicketingSystem.getInstance();
			ticketingSystem.exitVehicle(Int32.Parse(commandStringArray[1]));
			return "Slot number " + commandStringArray[1] + " is free";
		}
	}

	/**
	 * holds the responsibility of implementing status command
	 *
	 */
	private class StatusCommand : Command
{
		private String[] commandStringArray;

public StatusCommand(string[] s)
{
	commandStringArray = s;
}

public void validate()
{
	if (commandStringArray.Length != 1)
	{
		throw new Exception("status command should have no arguments");
	}
}

public String execute()
{
	TicketingSystem ticketingSystem = TicketingSystem.getInstance();
	List<StatusResponse> statusResponseList = ticketingSystem.getStatus();

	StringBuilder outputStringBuilder = new StringBuilder("Slot No.    Registration No    Colour");
	foreach (StatusResponse statusResponse in statusResponseList)
	{
		outputStringBuilder.Append("\n").Append(statusResponse);
	}
	return outputStringBuilder.ToString();
}
	}


	/**
	 * holds the responsibility of implementing
	 * registration_numbers_for_cars_with_colour command
	 *
	 */
	private class RegistrationNumbersForColorCommand : Command
{
		public string[] commandStringArray;

public RegistrationNumbersForColorCommand(String[] s)
{
	commandStringArray = s;
}

public void validate()
{
	if (commandStringArray.Length != 2)
	{
		throw new Exception(
				"registration_numbers_for_cars_with_colour command should have exactly 1 argument");
	}
}

public String execute()
{
	TicketingSystem ticketingSystem = TicketingSystem.getInstance();
	List<String> registrationNumbersList = ticketingSystem
			.getRegistrationNumbersFromColor(commandStringArray[1]);
	StringBuilder outputStringBuilder = new StringBuilder();
	foreach (string registrationNumber in registrationNumbersList)
	{
		if (outputStringBuilder.Length > 0)
		{
			outputStringBuilder.Append(", ");
		}
		outputStringBuilder.Append(registrationNumber);
	}
	return outputStringBuilder.ToString();
}
	}

	/**
	 * holds the responsibility of implementing slot_numbers_for_cars_with_colour
	 * command
	 *
	 */
	private class SlotNumbersForColorCommand : Command
{
		private String[] commandStringArray;

public SlotNumbersForColorCommand(String[] s)
{
	commandStringArray = s;
}

public void validate()
{
	if (commandStringArray.Length != 2)
	{
		throw new Exception(
				"slot_numbers_for_cars_with_colour command should have exactly 1 argument");
	}
}

public String execute()
{
	TicketingSystem ticketingSystem = TicketingSystem.getInstance();
	List<int> slotNumbersList = ticketingSystem.getSlotNumbersFromColor(commandStringArray[1]);
	StringBuilder outputStringBuilder = new StringBuilder();
	foreach (int slotNumber in slotNumbersList)
	{
		if (outputStringBuilder.Length > 0)
		{
			outputStringBuilder.Append(", ");
		}
		outputStringBuilder.Append(slotNumber);
	}
	return outputStringBuilder.ToString();
}
	}

	/**
	 * holds the responsibility of implementing slot_number_for_registration_number
	 * command
	 *
	 */
	public class SlotNumberCommand : Command
{
		private String[] commandStringArray;

public SlotNumberCommand(String[] s)
{
	commandStringArray = s;
}

public void validate()
{
	if (commandStringArray.Length != 2)
	{
		throw new Exception(
				"slot_number_for_registration_number command should have exactly 1 argument");
	}
}

public String execute()
{
	TicketingSystem ticketingSystem = TicketingSystem.getInstance();
	int slotNumber = ticketingSystem.getSlotNumberFromRegistrationNumber(commandStringArray[1]);
	return "" + slotNumber;
}
	}

}
}
